# Global Exception 처리 개념을 순수 자바로 먼저 만들기

이 장에서는 **예외 처리 책임**을 App에서 분리하여,
전용 컴포넌트인 **ExceptionHandler(Resolver)** 를 도입한다.

목표는 다음 한 문장이다.

> “예외를 어디서 어떻게 처리할지의 책임을 App에서 분리한다”

---

## 0. 이 장의 위치

현재 구조는 여기까지 왔다.

```text
App
 ↓
Dispatcher
 ↓
Controller
 ↓
Service
 ↓
Repository
```

이제 남은 문제는 하나다.

* Service/Controller에서 예외가 발생하면
* App에서 `try-catch`로 모두 처리하고 있다

즉, App이 **예외 처리자 역할**까지 하고 있다.

---

## 1. 현재 App의 문제점

App에 예외 처리가 들어가면, App은 “실행” 말고도 다음을 고민해야 한다.

* 어떤 예외를 어떻게 출력할지
* 사용자에게 어떤 메시지를 보여줄지
* 로그를 어디까지 남길지
* 예외가 늘어날수록 `catch`가 커짐

예를 들어 App이 이런 형태로 커진다.

```java
try {
    String result = dispatcher.dispatch(path, body);
    System.out.println("[App] result = " + result);
} catch (IllegalArgumentException e) {
    System.out.println("400 Bad Request: " + e.getMessage());
} catch (RuntimeException e) {
    System.out.println("500 Internal Server Error");
} catch (Exception e) {
    System.out.println("500 Unknown Error");
}
```

이건 “프로그램 시작점”인 App의 책임을 넘는다.

---

## 2. Global Exception 처리란 무엇인가

Global Exception 처리는 한 문장으로 끝난다.

```text
“예외를 한 곳에서 모아서, 일관된 방식으로 처리한다”
```

핵심은 다음 2가지다.

1. 예외를 “분류”한다 (예: 사용자 입력 오류 vs 서버 오류)
2. 예외 응답 형태를 “통일”한다 (예: 메시지 포맷, 코드)

---

## 3. 도입 후 구조

예외 처리를 전담하는 컴포넌트를 하나 둔다.

```text
App
 ↓
Runner(실행 담당)
 ↓
Dispatcher
 ↓
Controller
 ↓
Service
 ↓
Repository

(예외가 발생하면)
Runner → ExceptionHandler 로 위임
```

여기서 포인트:

* Dispatcher는 여전히 “어디로 보낼지”만 판단
* Controller/Service/Repository는 예외를 “던지기만” 한다
* 예외 해석/출력은 ExceptionHandler가 담당

---

## 4. ExceptionHandler 클래스 만들기

`ExceptionHandler`

```java
public class ExceptionHandler {

    public String handle(Exception e) {

        // 1) 사용자가 잘못 보낸 요청(입력값 문제)
        if (e instanceof IllegalArgumentException) {
            return "400 Bad Request: " + e.getMessage();
        }

        // 2) 나머지는 서버 내부 문제로 취급
        return "500 Internal Server Error: " + e.getClass().getSimpleName();
    }
}
```

핵심 포인트:

* “예외를 문자열로 바꿔주는” 책임만 가진다
* 예외 종류가 늘어나면 이곳만 수정한다

---

## 5. Runner(실행 담당) 만들기

App에서 `try-catch`를 없애려면,
“실행 + 예외 처리”를 묶어서 처리하는 전용 클래스를 둔다.

`Runner`

```java
import java.util.Map;

public class Runner {

    private final Dispatcher dispatcher;
    private final ExceptionHandler exceptionHandler;

    public Runner(Dispatcher dispatcher, ExceptionHandler exceptionHandler) {
        this.dispatcher = dispatcher;
        this.exceptionHandler = exceptionHandler;
    }

    public String run(String path, Map<String, Object> body) {
        try {
            return dispatcher.dispatch(path, body);
        } catch (Exception e) {
            return exceptionHandler.handle(e);
        }
    }
}
```

핵심 포인트:

* App이 하던 try-catch 책임이 Runner로 이동
* Runner는 “실행 흐름”만 담당한다

---

## 6. App 수정하기

이제 App은 진짜로 “조립 + 실행”만 한다.

```java
import com.koreanit.spring.*;
import java.util.HashMap;
import java.util.Map;

public class App {

    public static void main(String[] args) {

        // 1) 객체 조립
        UserRepository repository = new UserRepository();
        UserService service = new UserService(repository);
        UserController controller = new UserController(service);

        Dispatcher dispatcher = new Dispatcher(controller);
        ExceptionHandler exceptionHandler = new ExceptionHandler();
        Runner runner = new Runner(dispatcher, exceptionHandler);

        // 2) 요청 구성
        String path = args.length > 0 ? args[0] : "";
        Map<String, Object> body = new HashMap<>();
        if (args.length > 1) body.put("username", args[1]);
        if (args.length > 2) body.put("password", args[2]);

        // 3) 최종 실행 (App은 try-catch 없음)
        String result = runner.run(path, body);
        System.out.println("[App] result = " + result);

        System.out.println("[App] 정상 종료");
    }
}
```

---

## 7. 책임 이동 요약

```text
[이전]
App → 조립 + 실행 + try-catch + 예외 메시지 결정

[이후]
App → 조립 + 실행 호출만
Runner → 실행 + 예외를 한 곳으로 모음
ExceptionHandler → 예외 분류 + 응답 문자열 생성
```

---

## 실습 1. 예외 종류 늘려보기

### 목표

예외가 늘어나도 App/Dispatcher가 안 변하는 걸 체감한다.

### 실습 내용

1. `UserService`에서 상황별 예외 던지기

```java
if (username == null || username.isBlank()) {
    throw new IllegalArgumentException("username 이 필요합니다");
}
if ("admin".equals(username)) {
    throw new IllegalArgumentException("admin은 사용할 수 없습니다");
}
```

2. `ExceptionHandler`에서 메시지 통일 확인

* 입력값 예외는 항상 `400 Bad Request: ...`
* 그 외는 항상 `500 Internal Server Error: ...`

---

## 8. Spring으로의 연결

지금 만든 구조는 Spring의 전형적인 흐름과 대응된다.

```text
Runner(try-catch 모음)         → Filter/Interceptor/DispatcherServlet 경계
ExceptionHandler(handle)        → @ControllerAdvice + @ExceptionHandler
예외 분류(IllegalArgument...)   → HTTP 400/500 매핑
```

---

## 다음 단계

* “요청 바디(body)”를 Map으로 받는 걸 넘어서
* **DTO(요청 객체)** 로 바꾸고
* **검증/변환 책임**을 Controller 쪽으로 정리하기
