# Dispatcher 개념을 순수 자바로 먼저 만들기

이 장에서는 **요청 분배 책임**을 App에서 분리하여,
전용 컴포넌트인 **Dispatcher**를 도입한다.

목표는 다음 한 문장이다.

> "요청이 어디로 가야 하는지를 판단하는 책임을 App에서 분리한다"

---

## 0. 이 장의 위치

이전 장까지 우리는 다음 구조를 완성했다.

```text
App
 ↓
Controller
 ↓
Service
 ↓
Repository
```

이 구조는 **비즈니스 로직과 데이터 접근**은 잘 분리되어 있지만,
아직 한 가지 문제가 남아 있다.

---

## 1. 현재 App의 문제점

`App`은 지금 너무 많은 책임을 가지고 있다.

```java
if ("/hello".equals(path)) {
    result = controller.hello(body);
} else {
    result = "404 Not Found";
}
```

App은 지금 다음을 모두 알고 있다.

* 요청 경로(path)
* 어떤 Controller 메서드를 호출할지
* 존재하지 않는 요청 처리(404)

즉, App이 **요청 분배자 역할**까지 하고 있다.

---

## 2. Dispatcher란 무엇인가

Dispatcher는 다음 한 가지 책임만 가진다.

```text
"요청을 받아, 알맞은 처리 대상에게 전달한다"
```

Dispatcher는

* 비즈니스 로직을 모른다
* 데이터를 직접 다루지 않는다
* 결과를 해석하지 않는다

오직 **"어디로 보낼지"만 판단**한다.

---

## 3. Dispatcher 도입 후 구조

Dispatcher를 도입하면 구조는 다음과 같이 바뀐다.

```text
App
 ↓
Dispatcher  ← 요청 분배 전담
 ↓
Controller
 ↓
Service
 ↓
Repository
```

App은 더 이상

* path를 해석하지 않고
* Controller를 직접 호출하지 않는다

---

## 4. Dispatcher 클래스 만들기

`Dispatcher`

```java
import java.util.Map;

import com.koreanit.spring.UserController;

public class Dispatcher {

    private final UserController userController;

    public Dispatcher(UserController userController) {
        this.userController = userController;
    }

    public String dispatch(String path, Map<String, Object> body) {

        if ("/hello".equals(path)) {
            return userController.hello(body);
        }

        return "404 Not Found";
    }
}
```

핵심 포인트:

* Dispatcher는 Controller를 **의존**한다
* path 판단 책임이 App에서 이동했다

---

## 5. App 수정하기

이제 App은 요청 분배를 직접 하지 않는다.

```java
import com.koreanit.spring.*;

import java.util.HashMap;
import java.util.Map;

public class App {

    public static void main(String[] args) {

        // 1) 객체 조립
        UserRepository repository = new UserRepository();
        UserService service = new UserService(repository);
        UserController controller = new UserController(service);
        Dispatcher dispatcher = new Dispatcher(controller);

        // 2) 요청 정보 구성
        String path = args.length > 0 ? args[0] : "";

        Map<String, Object> body = new HashMap<>();
        if (args.length > 1) body.put("username", args[1]);

        // 3) 최종 호출
        try {
            String result = dispatcher.dispatch(path, body);
            System.out.println("[App] result = " + result);
        } catch (Exception e) {
            System.out.println("[App] 예외 발생: " + e);
        }

        System.out.println("[App] 정상 종료");
    }
}
```

---

## 6. 책임 이동 요약

```text
[이전]
App → path 판단 + Controller 호출

[이후]
App → 조립 + 실행
Dispatcher → 요청 분배
```

App은 **"프로그램 시작점" 역할로만 축소**되었다.

---

## 실습 1. 요청 추가 시 변화 확인

### 목표

Dispatcher가 없다면 App이 어떻게 복잡해지는지 체감한다.

### 실습 내용

1. `UserController`에 메서드 추가

```java
public String ping() {
    return "pong";
}
```

2. Dispatcher에 path 추가

```java
if ("/ping".equals(path)) {
    return userController.ping();
}
```

3. 실행

```bash
java App /ping
```

### 체크 포인트

* App은 전혀 수정되지 않는다
* 요청 분배 변경은 Dispatcher에만 집중된다

---

## Spring으로의 연결

이 Dispatcher는 Spring의 핵심 클래스와 정확히 대응된다.

```text
Dispatcher  → DispatcherServlet
path 문자열 → @RequestMapping
```

지금은 수동으로 작성했지만,
Spring은 이 과정을 자동화해준다.

---

## 다음 단계

→ [**Global Exception 처리 개념을 순수 자바로 먼저 만들기**](09-global-exception.md)
