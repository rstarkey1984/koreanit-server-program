# 예외 전파 핵심 정리

이 장에서는 자바에서 예외가 **어떻게 전달되고, 언제 처리되며, 왜 특정 위치에서만 catch 해야 하는지**를 개념적으로 정리한다.

이 내용은 이후 **Global Exception 처리 구조**로 확장하기 위한 필수 전제다.

---

## 0. 호출 스택(Call Stack)이란?

* **메서드가 호출되는 순서를 위에서 아래로 쌓아두는 실행 기록 공간**이다
* 메서드가 호출되면 스택에 쌓이고
* 메서드가 종료되면 스택에서 제거된다

즉,

> 지금 어떤 메서드가 실행 중이고,
> 그 메서드를 누가 호출했는지를 기억하는 구조다

### 호출 스택 예시

```text
main()
 └─ controller()
       └─ service()
             └─ repository()
```

* 현재 실행 중: `repository()`
* 이 메서드를 호출한 순서가 그대로 **호출 스택**이다

---

## 1. 예외 전파란?

* 예외가 발생하면 **현재 메서드에서 즉시 중단**된다

* 중단이 되면 **호출 스택(Call Stack)을 따라 거슬러 올라간다**

* 발생한 예외는 잡힐때까지 전달된다.

### 예외가 “잡힌다”의 정확한 의미

> **발생한 예외 타입을 처리할 수 있는 `catch`가 호출 스택 어딘가에 존재하면**
  → 그 예외는 잡힌 것이다

---

## 3. 예외가 잡히는 조건

예외가 잡히기 위해서는 **모든 조건을 만족**해야 한다.

* `catch`가 존재해야 한다

* `catch`의 타입이 **발생한 예외 타입과 같거나 부모 타입**이어야 한다

* 예외가 잡혀서 해당 `catch`가 실행되는 순간 **예외 전파는 중단된다**

```java
try {
    throw new IllegalArgumentException();
} catch (IllegalArgumentException e) {
    // 여기서 처리 → 전파 중단
}
```

---

## 4. 예외가 잡히지 않는 경우

### 1) catch 자체가 없는 경우

```java
throw new RuntimeException();
```

* 호출 스택 끝까지 전파
* JVM이 처리 → 프로그램 종료

---

### 2) catch는 있으나 타입이 맞지 않는 경우

```java
try {
    throw new RuntimeException();
} catch (IOException e) {
}
```

* 타입 불일치
* 해당 `catch`는 실행되지 않음
* 예외는 계속 전파됨

---

## 5. catch 실행의 의미

* `catch` 블록이 실행되는 순간
  → 해당 예외 객체는 **처리된 것으로 간주**된다
* 처리된 예외는 **더 이상 호출 스택을 따라 전파되지 않는다**

단, 다음 경우는 예외다.

```java
catch (RuntimeException e) {
    throw e; // 다시 던지면 새로운 전파 시작
}
```

---

## 6. catch는 단 하나만 실행된다

* 호출 스택 전체에서
  **가장 먼저 만나는 처리 가능한 catch 하나만 실행**된다
* 여러 catch가 동시에 실행되는 일은 없다

---

## 최종 요약

* 예외는 **호출 스택을 따라 위로 전파된다**
* 예외가 잡힌다는 것은
  → **처리 가능한 catch가 호출 스택에 존재한다는 뜻**이다
* `catch`가 실행되면 **예외 전파는 즉시 중단**된다
* 끝까지 잡히지 않으면 **JVM이 처리하고 프로그램은 종료된다**

---

# 실습: Error.java로 예외 전파 흐름 확인

이 실습에서는 **호출 스택을 따라 예외가 어떻게 전달되고, 어디서 멈추는지**를 직접 확인한다.
Global Exception 처리 구조로 가기 전 **개념을 코드로 고정**하는 단계다.

---

## 1. Error.java 파일 생성

`src/Error.java`

```java
public class Error {

    public static void main(String[] args) {
        System.out.println("[main] start");

        try {
            controller(args);
            System.out.println("[main] 정상 종료");
        } catch (Exception e) {
            System.out.println("[main] catch 실행: " + e.getClass().getSimpleName());
        }

        System.out.println("[main] end");
    }

    static void controller(String[] args) {
        System.out.println("[controller] 호출됨");
        service(args);
        System.out.println("[controller] 종료");
    }

    static void service(String[] args) {
        System.out.println("[service] 호출됨");
        repository(args);
        System.out.println("[service] 종료");
    }

    static void repository(String[] args) {
        System.out.println("[repository] 호출됨");

        if (args.length == 0) {
            throw new IllegalArgumentException("인자 없음");
        }

        System.out.println("[repository] 정상 처리");
    }
}
```

---

## 2. 실행 실습 ① : 인자 없이 실행

```bash
java Error
```

확인할 것:

* `repository`에서 예외 발생
* `repository` 이후 코드는 실행되지 않음
* `service 종료`, `controller 종료`는 출력되지 않음
* 예외는 `main`의 catch에서 잡힘

👉 **예외가 호출 스택을 따라 위로 전달됨**을 확인한다.

---

## 3. 실행 실습 ② : 인자 전달 후 실행

```bash
java Error hello
```

확인할 것:

* 모든 메서드가 정상 종료됨
* catch 블록은 실행되지 않음

---

## 4. catch 위치 변경 실습

`try-catch` 를 `controller`에 추가해본다.

```java
static void controller(String[] args) {
    try {
        System.out.println("[controller] 호출됨");
        service(args);
        System.out.println("[controller] 종료");
    } catch (Exception e) {
        System.out.println("[controller] catch 실행");
    }
}
```

확인할 것:

* 예외는 `controller`에서 잡힘
* `main`의 catch는 실행되지 않음

👉 **가장 먼저 만나는 catch 하나만 실행됨**을 확인한다.

---

## 5. 다시 던지기 실습 (rethrow)

`controller`의 catch에서 예외를 다시 던진다.

```java
catch (Exception e) {
    System.out.println("[controller] catch 실행 후 다시 던짐");
    throw e;
}
```

확인할 것:

* `controller`의 catch 실행됨
* 이후 `main`의 catch도 실행됨

👉 **catch에서 다시 던지면 새로운 예외 전파가 시작된다**.

---

## 6. NullPointerException 타입 에러 일때만 던지기


```java
catch (Exception e) {
    
    if (e instanceof NullPointerException){
      throw e;
    }else{
      System.out.println(e);
    }

}
```

## 한 문장 정리

> 예외는 발생한 메서드에서 멈추고,
> 처리 가능한 catch를 만날 때까지
> 호출 스택을 따라 위로 전달된다.

---

## Spring 연결 문장

* `repository` / `service` → 예외 발생 후 throw
* `controller` → 성공일때 return 만 함
* `Global Exception Handler` → 에러를 받아서 일괄 처리

이 구조가 Spring 예외 처리의 그대로인 형태다.

---

## 다음 단계

[**Controller에서 return으로 값 전달하기**](04-controller-parameter-and-return.md)
